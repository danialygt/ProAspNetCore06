﻿namespace Asp06Store.Framework
{
    public class Class1
    {

    }
}