﻿namespace Asp06Store.ShopUI.Models;

public interface ICategoryRepository
{
    List<string> GetAllCategories();
}

