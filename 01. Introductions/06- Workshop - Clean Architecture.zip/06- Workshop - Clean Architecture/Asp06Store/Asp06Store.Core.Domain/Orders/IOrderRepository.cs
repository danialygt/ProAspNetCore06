﻿namespace Asp06Store.ShopUI.Models;
public interface IOrderRepository
{
    void Save(Order order);
}
