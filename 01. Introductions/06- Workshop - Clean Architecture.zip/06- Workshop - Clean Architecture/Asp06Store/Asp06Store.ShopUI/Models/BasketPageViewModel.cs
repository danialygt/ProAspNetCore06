﻿namespace Asp06Store.ShopUI.Models
{
    public class BasketPageViewModel
    {
        public Basket Basket { get; set; }
        public string ReturnUrl { get; set; }
    }
}
