﻿global using Asp06Store.ShopUI.Extentions;
global using Asp06Store.ShopUI.Models;
global using Microsoft.AspNetCore.Mvc;