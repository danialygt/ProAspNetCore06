﻿namespace Asp06Store.Infra.Data.Sql
{
    public class Class1
    {

    }
}